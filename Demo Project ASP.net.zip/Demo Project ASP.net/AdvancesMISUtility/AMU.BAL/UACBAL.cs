﻿using AMU.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMU.BAL
{
    public class UACBAL
    {
        UACDAL objDAL = new UACDAL();

        public DataSet Login(string Username, string Password)
        {
            DataSet ds = null;
            try
            {
                string EmployeeName = string.Empty;
                long EmployeeId = 0;
                string AdminUserList = string.Empty;

                if (AdAuthentication(Username, Password, out EmployeeId, out EmployeeName))
                {
                    ds = new DataSet();
                    ds = objDAL.GetEmployeeDetail(EmployeeId);
                    if (ds != null)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            return ds;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                CommonDAL.WritefileLog("UACBAL Login -- >", ex.Message.ToString());
            }
            return ds;
        }

        public static bool AdAuthentication(string Username, string Password, out long EmployeeId, out string EmployeeName)
        {
            bool flag = false;
            string LDapStr = string.Empty;
            EmployeeId = 0;
            EmployeeName = "";

            try
            {
                LDapStr = ConfigurationManager.AppSettings["LDapStr"].ToString();
                DirectoryEntry ObjDE = new DirectoryEntry(LDapStr, Username, Password);
                DirectorySearcher ObjDirSearch = new DirectorySearcher(ObjDE);
                ObjDirSearch.Filter = "(samaccountname=" + Username + ")";
                ObjDirSearch.PropertiesToLoad.Add("employeeid");
                ObjDirSearch.PropertiesToLoad.Add("name");
                SearchResult objSearchResult = ObjDirSearch.FindOne();

                if (objSearchResult != null)
                {
                    EmployeeId = Convert.ToInt64(objSearchResult.Properties["employeeid"][0]);
                    EmployeeName = Convert.ToString(objSearchResult.Properties["name"][0]);
                    flag = true;
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }

            return flag;
        }

    }
}
