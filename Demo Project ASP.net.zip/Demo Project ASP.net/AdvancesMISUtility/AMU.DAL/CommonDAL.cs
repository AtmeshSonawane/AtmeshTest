﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMU.DAL
{
    public class CommonDAL
    {
        public const long MaxLogFileSize = 100000;

        public static void WritefileLog(string lCategory, string lMessage, Int16 lSeverity = 1)
        {
            string lstrFileName;
            string lstrNewFileName;
            System.IO.FileInfo fInfo;
            string strFolderPath = System.Configuration.ConfigurationSettings.AppSettings["LogFile"].ToString();
            try
            {
                strFolderPath = strFolderPath + string.Format(DateTime.Now.ToString("ddMMMyyyy") + ".txt");
                using (StreamWriter sw = File.AppendText(strFolderPath))
                {
                    sw.WriteLine(DateTime.Now.ToString("dd-MMM-yyyy hh:MM:ss") + " <----> " + lCategory + lMessage);
                }

                lstrFileName = strFolderPath + string.Format(DateTime.Now.ToString("ddMMMyyyy")) + ".txt";
                fInfo = new System.IO.FileInfo(lstrFileName);

                if (fInfo.Length == MaxLogFileSize)
                {
                    // ' rename the old file as new file name
                    lstrNewFileName = strFolderPath + string.Format(DateTime.Now.ToString("ddMMMyyyyhhmmss")) + ".txt";
                    File.Move(lstrFileName, lstrNewFileName);
                }

                // in case of critical error log in the eventvwr
                if (lSeverity == 9)
                    System.Diagnostics.EventLog.WriteEntry(lCategory, lMessage);
            }
            catch (Exception)
            {

            }
        }
        
    }
}
