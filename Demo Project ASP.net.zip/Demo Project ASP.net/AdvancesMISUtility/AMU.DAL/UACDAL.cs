﻿using Microsoft.ApplicationBlocks.Data;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMU.DAL
{
    public class UACDAL
    {

        public static string ConStrHRMSConStr
        {
            get { return ConfigurationManager.ConnectionStrings["HRMSConStr"].ConnectionString; }
        }

        public DataSet GetEmployeeDetail(long pEmployeeId)
        {
            DataSet ds = new DataSet();
            DataSet bds = new DataSet();
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@pEmployeeId", SqlDbType.Int);
                arParms[0].Value = pEmployeeId;

                ds = SqlHelper.ExecuteDataset(ConStrHRMSConStr, CommandType.StoredProcedure, "SPGetOLMEmployeeDetails", arParms);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ds;
        }

    }
}
