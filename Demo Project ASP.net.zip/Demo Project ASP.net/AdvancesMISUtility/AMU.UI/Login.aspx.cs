﻿using AMU.BAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.DirectoryServices;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMU.UI
{
    public partial class Login : System.Web.UI.Page
    {
        UACBAL balObj = new UACBAL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CmdAuthenticate_Click(object sender, EventArgs e)
        {
            DataSet ds = null;
            string response = string.Empty;
            try
            {
                if (txtUserName.Text.Trim() == "")
                {
                    lblError.Text = "Enter your username";
                    return;
                }
                if (txtPassword.Text.Trim() == "")
                {
                    lblError.Text = "Enter your password";
                    return;
                }

                if (txtUserName.Text.Trim() != "" && txtPassword.Text.Trim() != "")
                {
                    ds = balObj.Login(txtUserName.Text.Trim(), txtPassword.Text.Trim());
                    if (ds != null)
                    {
                        Session["EmployeeId"] = Convert.ToString(ds.Tables[0].Rows[0]["EmployeeId"]);
                        Session["UserName"] =Convert.ToString(ds.Tables[0].Rows[0]["EmployeeName"]);
                        Response.Redirect("DashBoard.aspx");
                    }
                    else
                    {
                        Session["RefNo"] = null;
                        Session["SecReqId"] = null;
                        lblError.Text = "Authentication Failed";
                    }
                }
                else
                {
                    lblError.Text = "invalid credencial";
                    return;
                }
                
            }
            catch (Exception EX)
            {
                throw;
            }
        }
    }
}