﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMU.UI.UserControl
{
    public partial class TopHeadingBar : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToString(Session["UserName"]) != "" && Convert.ToInt32(Session["EmployeeId"]) != 0)
            {
                btnSignOut.Visible = true;
                SignOutLi.Visible = true;
                NameLi.Visible = true;
                lblUserName.Text = Convert.ToString(Session["UserName"]);                
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            Session["UserName"] = "";
            Session["EmployeeId"] = "";
            Response.Redirect("Login.aspx");
        }
    }
}